Instructions for Running:

This program can be run by first installing all python library requirements from requirements.txt with the command: 

pip install -r requirements.txt

The requirements are also listed here if you would like to install them one-by-one:
numpy, pandas, matplotlib

python 3.12.3

Then, simply run main.py. You may wish to reduce the number of simulations at the top of main(), since at the given values the run took close to an hour.